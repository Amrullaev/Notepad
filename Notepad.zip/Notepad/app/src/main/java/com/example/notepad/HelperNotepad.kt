package com.example.notepad

interface HelperNotepad {
    fun onItemClicked(note: Note)
}